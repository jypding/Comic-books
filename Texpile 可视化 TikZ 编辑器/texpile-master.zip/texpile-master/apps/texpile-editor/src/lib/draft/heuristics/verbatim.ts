// Commands and environments that change catcodes WHILE TeX scans their argument (\verb's
// delimited body, \url's specials, verbatim env bodies). No static catcode table -- not
// even the engine's own -- can see inside them, so this list is irreducibly a heuristic.
// The lexing guards mask these spans before scanning; the DISPATCHED text still ships raw,
// and the engine applies the true dynamic catcodes.

// argument delimited by the next character (body runs to its next occurrence)
const DELIM_CMDS = ['verb\\*?', 'Verb\\*?', 'lstinline'];
// argument brace-delimited; TeX keeps braces grouping inside, so a matching-brace scan IS
// the engine's own parse. Only the FIRST braced argument is verbatim-read.
const BRACED_CMDS = ['url', 'nolinkurl', 'path', 'href'];
// body runs to the literal \end{env}; nothing inside nests
const VERB_ENVS = [
	'verbatim\\*?',
	'Verbatim\\*?',
	'BVerbatim',
	'LVerbatim',
	'lstlisting',
	'minted',
	'alltt',
	'filecontents\\*?',
	'comment'
];

const DELIM_RE = new RegExp(`\\\\(?:${DELIM_CMDS.join('|')})(?![a-zA-Z])`, 'g');
const BRACED_RE = new RegExp(`\\\\(?:${BRACED_CMDS.join('|')})(?![a-zA-Z])\\s*\\{`, 'g');
const ENV_RE = new RegExp(`\\\\begin\\{(${VERB_ENVS.join('|')})\\}`, 'g');
export const VERB_ENV_RE = new RegExp(`^(?:${VERB_ENVS.join('|')})$`);

export type Span = { start: number; end: number };

/** [start, end) spans of verbatim-scanned material in s (bodies only, delimiters included) */
export function verbatimSpans(s: string): Span[] {
	const out: Span[] = [];
	DELIM_RE.lastIndex = 0;
	for (let m = DELIM_RE.exec(s); m; m = DELIM_RE.exec(s)) {
		const d = s[DELIM_RE.lastIndex];
		if (d === undefined || d === '\n') continue;
		const close = s.indexOf(d, DELIM_RE.lastIndex + 1);
		out.push({ start: DELIM_RE.lastIndex, end: close < 0 ? s.length : close + 1 });
		if (close >= 0) DELIM_RE.lastIndex = close + 1;
	}
	BRACED_RE.lastIndex = 0;
	for (let m = BRACED_RE.exec(s); m; m = BRACED_RE.exec(s)) {
		let depth = 1;
		let i = BRACED_RE.lastIndex;
		while (i < s.length && depth > 0) {
			if (s[i] === '{') depth++;
			else if (s[i] === '}') depth--;
			i++;
		}
		out.push({ start: BRACED_RE.lastIndex, end: depth === 0 ? i - 1 : s.length });
	}
	ENV_RE.lastIndex = 0;
	for (let m = ENV_RE.exec(s); m; m = ENV_RE.exec(s)) {
		const close = s.indexOf(`\\end{${m[1]}}`, ENV_RE.lastIndex);
		out.push({ start: ENV_RE.lastIndex, end: close < 0 ? s.length : close });
		if (close >= 0) ENV_RE.lastIndex = close;
	}
	return out.sort((a, b) => a.start - b.start);
}

/** s with verbatim bodies blanked to spaces (newlines kept, so line structure survives) */
export function maskVerbatim(s: string): string {
	const spans = verbatimSpans(s);
	if (!spans.length) return s;
	const chars = s.split('');
	for (const { start, end } of spans) for (let i = start; i < end; i++) if (chars[i] !== '\n') chars[i] = ' ';
	return chars.join('');
}
