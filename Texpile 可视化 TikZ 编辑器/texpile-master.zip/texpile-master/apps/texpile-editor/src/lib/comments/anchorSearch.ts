// exact anchoring: build a quote-plus-context anchor and find it again, ranking candidate
// hits by how much of the remembered context still lines up
/** how much text either side is kept, to tell repeated quotes apart */
export const CONTEXT = 32;

export const MIN_QUOTE = 3;

export const POINT_CONTEXT = 12;
export const POINT_WEAK = 24;
const NEEDLE = 8;

/** a runaway scan guard: past this many hits the quote is not distinctive enough to place */
export const MAX_HITS = 500;

export type CommentAnchor = {
	/** the commented text itself */
	quote: string;
	/** text immediately before and after it, used to pick between repeats of the quote */
	prefix: string;
	suffix: string;
	/** where the quote sat when the comment was written; re-checked, never trusted */
	start: number;
	end: number;
	rank?: number;
};

export type ResolvedAnchor = {
	from: number;
	to: number;
	/** the offsets were still right - nothing has moved under this comment */
	exact: boolean;
	/**
	 * Found, but under WEAK_CONTEXT characters of the remembered surroundings line up. The words
	 * around the quote changed, and if the document holds the sentence twice this may be the OTHER
	 * copy: a single surviving copy is taken on the strength of the quote alone, because from here
	 * a sentence moved into a new paragraph looks exactly the same. Placed with a warning rather
	 * than detached - a reader loses a glance to the warning and a whole thread to a detach.
	 */
	weak: boolean;
	/** the stretch of the quote this hit stands for, when only a fragment of it could be placed */
	covers?: { from: number; to: number };
};

/** matched context characters (both sides together) under which a relocated hit is weak. What a
 *  duplicate shares by chance - a period and two newlines each side - scores about five. */
export const WEAK_CONTEXT = 8;

export function buildAnchor(text: string, from: number, to: number): CommentAnchor {
	return {
		quote: text.slice(from, to),
		prefix: text.slice(Math.max(0, from - CONTEXT), from),
		suffix: text.slice(to, Math.min(text.length, to + CONTEXT)),
		start: from,
		end: to
	};
}

/**
 * Find the anchor in `text`, or null if it has gone.
 *
 * Null means orphaned, and an orphaned comment must be SHOWN as orphaned rather than pinned to a
 * best guess: a review note parked on the wrong sentence is worse than one that admits it lost its
 * place, because the reader has no way to tell it is lying.
 */
export function resolveAnchor(text: string, a: CommentAnchor): ResolvedAnchor | null {
	if (a.quote.length < MIN_QUOTE) {
		const sure = Math.min(POINT_WEAK, a.prefix.length + a.suffix.length);
		if (text.slice(a.start, a.end) === a.quote && contextScore(text, a.start, a.end, a) >= sure)
			return { from: a.start, to: a.end, exact: true, weak: false };
		const hit = searchContext(text, a.quote, a.prefix, a.suffix, a.start);
		return hit ? { from: hit.from, to: hit.to, exact: false, weak: hit.context < sure } : null;
	}
	// the common case by far - the file has not been touched behind our back
	if (text.slice(a.start, a.end) === a.quote) return { from: a.start, to: a.end, exact: true, weak: false };
	const hit = searchQuote(text, a.quote, a.prefix, a.suffix, a.start);
	return hit ? { from: hit.from, to: hit.to, exact: false, weak: hit.context < WEAK_CONTEXT } : null;
}

export function resolveExactly(text: string, a: CommentAnchor): { from: number; to: number } | null {
	const whole = a.prefix + a.quote + a.suffix;
	if (text.slice(a.start - a.prefix.length, a.end + a.suffix.length) === whole) return { from: a.start, to: a.end };
	const hits = occurrences(text, whole);
	if (hits.length === 0 || hits.length >= MAX_HITS) return null;
	const at = hits.reduce((best, h) => (Math.abs(h + a.prefix.length - a.start) < Math.abs(best + a.prefix.length - a.start) ? h : best));
	return { from: at + a.prefix.length, to: at + a.prefix.length + a.quote.length };
}

/** the search behind resolveAnchor, shared with the loose path; `hint` breaks exact-score ties,
 *  `context` is how much of the surroundings matched at the pick (see ResolvedAnchor.weak) */
export function searchQuote(
	text: string,
	quote: string,
	prefix: string,
	suffix: string,
	hint: number,
	copy?: () => number
): { from: number; to: number; context: number } | null {
	if (quote.length < MIN_QUOTE) return null;
	const spots = quoteSpots(text, quote, prefix, suffix);
	if (!spots) return null;
	const a = { quote, prefix, suffix };
	if (spots.length === 1)
		return { from: spots[0], to: spots[0] + quote.length, context: contextScore(text, spots[0], spots[0] + quote.length, a) };

	// repeated quote: the context decides
	const tied = bestSpots(spots, (at) => contextScore(text, at, at + quote.length, a));
	const best = pickCopy(spots, tied.at, hint, copy);
	return { from: best, to: best + quote.length, context: tied.score };
}

export function searchContext(
	text: string,
	quote: string,
	prefix: string,
	suffix: string,
	hint: number,
	copy?: () => number
): { from: number; to: number; context: number } | null {
	const spots = quoteSpots(text, quote, prefix, suffix);
	if (!spots) return null;
	const a = { prefix, suffix };
	const tied = bestSpots(spots, (at) => contextScore(text, at, at + quote.length, a));
	if (tied.score < Math.min(POINT_CONTEXT, prefix.length + suffix.length)) return null;
	const best = pickCopy(spots, tied.at, hint, copy);
	return { from: best, to: best + quote.length, context: tied.score };
}

/**
 * Every place the quote occurs, in text order; the surroundings then rank them. Null when there
 * are none, or too many: the scan stops at MAX_HITS, so scoring what it collected would rank the
 * first 500 copies and ignore the rest - and a comment on `\begin` in a long document would land
 * confidently near the top of the file, which is precisely the lie this module exists to avoid.
 * Orphaned is the honest answer for a quote this repetitive.
 */
export function quoteSpots(text: string, quote: string, prefix: string, suffix: string): number[] | null {
	if (quote.length >= MIN_QUOTE) {
		const hits = occurrences(text, quote);
		return hits.length && hits.length < MAX_HITS ? hits : null;
	}
	const after = quote + suffix;
	const byAfter = after.length >= NEEDLE;
	const needle = byAfter ? after.slice(0, NEEDLE) : prefix.slice(-NEEDLE);
	if (!needle) return null;
	const hits = occurrences(text, needle);
	if (hits.length === 0 || hits.length >= MAX_HITS) return null;
	const spots = hits.map((h) => (byAfter ? h : h + needle.length)).filter((at) => text.slice(at, at + quote.length) === quote);
	return spots.length ? spots : null;
}

function bestSpots(spots: number[], score: (at: number) => number): { at: number[]; score: number } {
	let best: number[] = [];
	let bestScore = -1;
	for (const at of spots) {
		const s = score(at);
		if (s > bestScore) {
			bestScore = s;
			best = [at];
		} else if (s === bestScore) best.push(at);
	}
	return { at: best, score: bestScore };
}

// copies the context cannot tell apart: the one the quote was counted as elsewhere, if that is one of
// them, else whichever is nearest where the comment used to be, since edits move text a little more
// often than they move it a long way
function pickCopy(spots: number[], tied: number[], hint: number, copy?: () => number): number {
	if (tied.length === 1) return tied[0];
	const counted = copy && spots[copy()];
	if (counted !== undefined && tied.includes(counted)) return counted;
	return tied.reduce((best, at) => (Math.abs(at - hint) < Math.abs(best - hint) ? at : best));
}

/** the quote without the whitespace at its ends, which the rendered text may not keep beside it */
export function withoutEdgeSpace(a: CommentAnchor): CommentAnchor {
	const quote = a.quote.trim();
	const lead = quote ? a.quote.indexOf(quote) : a.quote.length;
	const tail = lead + quote.length;
	return {
		...a,
		quote,
		prefix: a.prefix + a.quote.slice(0, lead),
		suffix: a.quote.slice(tail) + a.suffix,
		start: a.start + lead,
		end: a.start + tail
	};
}

/** which occurrence of the quote sits at the anchor's own offset, when the text holds it more than once */
export function copyIndex(text: string, a: CommentAnchor): number {
	const spots = quoteSpots(text, a.quote, a.prefix, a.suffix);
	return spots ? Math.max(0, spots.indexOf(a.start)) : 0;
}

/** how many characters of the remembered context still line up around a candidate */
export function contextScore(text: string, from: number, to: number, a: Pick<CommentAnchor, 'prefix' | 'suffix'>): number {
	let score = 0;
	const before = text.slice(Math.max(0, from - a.prefix.length), from);
	for (let i = 1; i <= Math.min(before.length, a.prefix.length); i++) {
		if (before[before.length - i] !== a.prefix[a.prefix.length - i]) break;
		score++;
	}
	const after = text.slice(to, to + a.suffix.length);
	for (let i = 0; i < Math.min(after.length, a.suffix.length); i++) {
		if (after[i] !== a.suffix[i]) break;
		score++;
	}
	return score;
}

export function occurrences(text: string, needle: string): number[] {
	const out: number[] = [];
	for (let at = text.indexOf(needle); at !== -1; at = text.indexOf(needle, at + 1)) {
		out.push(at);
		if (out.length >= MAX_HITS) break;
	}
	return out;
}
